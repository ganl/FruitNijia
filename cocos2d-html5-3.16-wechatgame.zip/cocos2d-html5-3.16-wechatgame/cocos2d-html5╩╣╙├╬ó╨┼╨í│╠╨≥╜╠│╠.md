# **Cocos2d-JS 适配、打包微信小游戏教程**

## 准备工作

1. 从官方社区论坛下载含已经适配微信小游戏的 Cocos2d-html5 引擎 (基于Cocos2d-html5 v3.16版本) 和 WeChatGame 依赖文件。
2. 下载微信小程序工具[下载链接](https://mp.weixin.qq.com/debug/wxagame/dev/devtools/devtools.html?t=201814)

## 发布步骤

1. 将发布包的 frameworks/cocos2d-html5 替换为官方社区下载下来的微信小游戏定制版 Cocos2d-html5 引擎后，通过命令行 `cocos compile -p web -m release` 重新发布 web 版本。
2. 把 `WeChatGame` 内的文件拷贝到发布后 `publish/html5` 的目录下。
3. 由于小游戏上传资源限制为 4mb，所以当整体包体超过 4mb 的时候，需要将资源移到远程服务器中，如果包体没有超过限制，跳过步骤 4 和 5。
4. 把 `publish/html5` 目录下的 `project.json` 和 `res` 资源文件夹移到服务器目录下。注意：远程资源不应该超过 50mb，这是微信小游戏缓存空间的上限。
5. 开启服务器后，需要修改 `game.js` 中 `window.REMOTE_SERVER_ROOT` 为当前开启服务器的路径，这样才能加载到远程资源。
6. 打开微信工具点击创建小程序项目，项目目录选择打包后 `publish/html5` 的目录，添加 appid 和项目名称后进行创建项项目，就可以在微信工具中调试，发布微信小游戏了。（目前用户尚无法申请 appid，请使用微信开发者工具的 “体验小游戏” 功能）

## 几个注意事项：

1. 该解决方案暂时不包含远程资源加载的缓存和更新机制
2. 该版本小游戏的适配方案为社区版本，该版本主要让CP的现有游戏适配小游戏的进度加快，更好的使用体验请选择Cocos Creator。
3. 部分功能由于适配问题目前暂时无法使用，开发者可以参考微信小游戏 API 研究解决方案，目前暂时不支持的功能包括：cc.NodeGrid、ccui.WebView、ccui.VideoPlayer、ccui.TextField（可用 cc.EditBox 替代）。
4. Cocos2d-JS（Cocos2d-html5）适配小游戏的后续技术支持问题，请各位开发者在论坛里交流、讨论。