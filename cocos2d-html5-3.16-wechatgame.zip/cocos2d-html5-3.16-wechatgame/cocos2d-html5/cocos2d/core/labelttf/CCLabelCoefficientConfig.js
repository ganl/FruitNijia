/**
 * Created by malloyzhu on 2017/8/11.
 */

//字体大小与行高的系数配置
cc.LabelCoefficientConfig = {
    "Microsoft YaHei": 1.334,
    "Arial": 1.134
};
